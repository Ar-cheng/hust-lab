int main(){
	char c = 'a';
}